﻿using ContosoUniversity.Models;

namespace ContosoUniversity
{
    internal class SchoolContext
    {
        public object Students { get; internal set; }

        internal void AddRange(OfficeAssignment[] officeAssignments)
        {
            throw new NotImplementedException();
        }

        internal void SaveChanges()
        {
            throw new NotImplementedException();
        }

        internal void AddRange(Enrollment[] enrollments1)
        {
            throw new NotImplementedException();
        }
    }
}